/*
 * Illustrative product previews for the landing page. Every value shown here is
 * sample data that demonstrates an existing STORVA feature, not a real metric.
 */
import {
  Box,
  Check,
  CheckCheck,
  CreditCard,
  ImagePlus,
  LayoutGrid,
  Lock,
  Monitor,
  Package,
  Palette,
  Plus,
  QrCode,
  ShoppingBag,
  Smartphone,
  Sparkles,
  Store,
  Wallet,
} from "lucide-react";

import { cn } from "@/lib/utils";

function Bubble({ out, children }: { out?: boolean; children: React.ReactNode }) {
  return (
    <div className={cn("flex", out ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[85%] rounded-2xl px-3.5 py-2 text-[13px] leading-snug shadow-soft",
          out ? "rounded-br-md bg-primary text-primary-foreground" : "rounded-bl-md bg-card text-foreground",
        )}
      >
        {children}
      </div>
    </div>
  );
}

export function WhatsAppMock({ className }: { className?: string }) {
  return (
    <div className={cn("w-full overflow-hidden rounded-2xl border border-border bg-card shadow-soft", className)}>
      <div className="flex items-center gap-3 bg-deep px-4 py-3 text-deep-foreground">
        <span className="grid size-8 place-items-center rounded-full bg-primary-gradient">
          <Box className="size-4" />
        </span>
        <div className="leading-tight">
          <p className="text-sm font-semibold">STORVA</p>
          <p className="text-[11px] text-deep-muted">WhatsApp</p>
        </div>
      </div>
      <div className="space-y-2.5 bg-mint p-4">
        <Bubble out>Add: Chocolate truffle cake, ₹650, 10 in stock</Bubble>
        <Bubble>
          <span className="flex items-center gap-1.5 font-medium">
            <CheckCheck className="size-3.5 text-primary" /> Added to your store
          </span>
          <span className="mt-2 flex items-center gap-2.5 rounded-xl bg-mint p-2">
            <span className="size-9 shrink-0 rounded-lg bg-primary-gradient" />
            <span className="leading-tight">
              <span className="block text-xs font-semibold">Chocolate truffle cake</span>
              <span className="block text-[11px] text-muted-foreground">₹650 · 10 in stock</span>
            </span>
          </span>
        </Bubble>
        <Bubble out>Any new orders today?</Bubble>
        <Bubble>You have 3 new orders. Reply “orders” to see them.</Bubble>
      </div>
    </div>
  );
}

export function AiDraftMock({ className }: { className?: string }) {
  return (
    <div className={cn("w-full rounded-2xl border border-border bg-card p-3 shadow-soft", className)}>
      <div className="relative grid aspect-[4/3] place-items-center overflow-hidden rounded-xl bg-accent">
        <div className="absolute inset-0 bg-grid opacity-70" />
        <ImagePlus className="relative size-8 text-primary/70" />
        <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded-full bg-card px-2 py-1 text-[11px] font-semibold text-primary shadow-soft">
          <Sparkles className="size-3" /> Draft ready
        </span>
      </div>
      <div className="space-y-2 px-1 pb-1 pt-3">
        <div className="flex items-start justify-between gap-2">
          <p className="text-sm font-semibold">Handmade ceramic mug</p>
          <p className="text-sm font-semibold text-primary">₹480</p>
        </div>
        <div className="space-y-1.5">
          <div className="h-1.5 w-full rounded-full bg-muted" />
          <div className="h-1.5 w-4/5 rounded-full bg-muted" />
        </div>
        <div className="flex gap-2 pt-1.5">
          <span className="flex-1 rounded-lg border border-border py-1.5 text-center text-xs font-medium">Edit</span>
          <span className="flex-1 rounded-lg bg-primary py-1.5 text-center text-xs font-semibold text-primary-foreground">
            Review
          </span>
        </div>
      </div>
    </div>
  );
}

const checklist = [
  { label: "Store name", done: true },
  { label: "Business details", done: true },
  { label: "First product", done: true },
  { label: "Payments & delivery", done: false },
];

export function SetupMock({ className }: { className?: string }) {
  return (
    <div className={cn("w-full rounded-2xl border border-border bg-card p-4 shadow-soft", className)}>
      <div className="flex items-center justify-between text-xs">
        <span className="font-semibold">Store setup</span>
        <span className="text-muted-foreground">3 of 4</span>
      </div>
      <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-muted">
        <div className="h-full w-3/4 rounded-full bg-primary-gradient" />
      </div>
      <ul className="mt-4 space-y-2.5">
        {checklist.map((c) => (
          <li key={c.label} className="flex items-center gap-2.5 text-[13px]">
            <span
              className={cn(
                "grid size-5 place-items-center rounded-full",
                c.done ? "bg-primary text-primary-foreground" : "border-2 border-dashed border-primary/40",
              )}
            >
              {c.done && <Check className="size-3" strokeWidth={3} />}
            </span>
            <span className={c.done ? "text-muted-foreground line-through decoration-border" : "font-medium"}>
              {c.label}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

const swatches = ["bg-primary", "bg-deep", "bg-chart-1", "bg-chart-3", "bg-chart-4"];

export function DesignerMock({ className }: { className?: string }) {
  return (
    <div className={cn("grid w-full gap-3 sm:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]", className)}>
      <div className="space-y-4 rounded-2xl border border-border bg-card p-4 shadow-soft">
        <div>
          <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            <Palette className="size-3.5" /> Color
          </p>
          <div className="mt-2 flex gap-2">
            {swatches.map((s, i) => (
              <span
                key={s}
                className={cn("size-6 rounded-full", s, i === 0 && "ring-2 ring-primary ring-offset-2 ring-offset-card")}
              />
            ))}
          </div>
        </div>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Font</p>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <span className="rounded-lg border-2 border-primary bg-mint py-1.5 text-center text-sm font-semibold">Aa Sans</span>
            <span className="rounded-lg border border-border py-1.5 text-center font-serif text-base italic">Aa Serif</span>
          </div>
        </div>
        <div>
          <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            <LayoutGrid className="size-3.5" /> Layout
          </p>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className={cn(
                  "grid h-9 gap-0.5 rounded-md border p-1",
                  i === 0 ? "grid-cols-2 border-primary bg-mint" : i === 1 ? "grid-cols-1 border-border" : "grid-cols-3 border-border",
                )}
              >
                {Array.from({ length: i === 1 ? 1 : i === 0 ? 2 : 3 }).map((_, j) => (
                  <span key={j} className="rounded-sm bg-primary/20" />
                ))}
              </span>
            ))}
          </div>
        </div>
      </div>
      <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
        <div className="flex items-center justify-between border-b border-border px-3 py-2">
          <span className="flex gap-1">
            <span className="size-2 rounded-full bg-border" />
            <span className="size-2 rounded-full bg-border" />
            <span className="size-2 rounded-full bg-border" />
          </span>
          <span className="flex gap-1 text-muted-foreground">
            <Monitor className="size-3.5 text-primary" />
            <Smartphone className="size-3.5" />
          </span>
        </div>
        <div className="p-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold">Your store</span>
            <ShoppingBag className="size-3.5 text-primary" />
          </div>
          <div className="mt-2.5 rounded-xl bg-primary-gradient p-3 text-primary-foreground">
            <p className="text-sm font-semibold leading-tight">New collection</p>
            <span className="mt-2 inline-block rounded-full bg-card px-2.5 py-0.5 text-[10px] font-semibold text-primary">
              Shop now
            </span>
          </div>
          <div className="mt-2.5 grid grid-cols-2 gap-2">
            {[0, 1].map((i) => (
              <div key={i} className="space-y-1">
                <div className="aspect-square rounded-lg bg-accent" />
                <div className="h-1.5 w-3/4 rounded-full bg-muted" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const orders = [
  { name: "Ananya R.", item: "Croissant box ×2", total: "₹480", status: "New" },
  { name: "Rahul K.", item: "Linen kurta", total: "₹1,250", status: "Packed" },
  { name: "Fathima S.", item: "Gift hamper", total: "₹899", status: "Delivered" },
];

const stats = [
  { label: "Orders today", value: "12", icon: ShoppingBag },
  { label: "Products", value: "48", icon: Package },
  { label: "Low stock", value: "3", icon: Box },
];

export function DashboardMock({ className }: { className?: string }) {
  return (
    <div className={cn("w-full overflow-hidden rounded-3xl border border-border bg-card text-foreground shadow-elevated", className)}>
      <div className="flex items-center justify-between border-b border-border bg-mint/60 px-4 py-3">
        <span className="flex gap-1.5">
          <span className="size-2.5 rounded-full bg-border" />
          <span className="size-2.5 rounded-full bg-border" />
          <span className="size-2.5 rounded-full bg-border" />
        </span>
        <span className="rounded-full border border-border bg-card px-2.5 py-0.5 text-[10px] font-medium text-muted-foreground">
          Sample data
        </span>
      </div>
      <div className="grid sm:grid-cols-[150px_minmax(0,1fr)]">
        <aside className="hidden space-y-1 border-r border-border p-3 text-[13px] sm:block">
          {[
            { label: "Overview", icon: LayoutGrid, active: true },
            { label: "Products", icon: Package },
            { label: "Orders", icon: ShoppingBag },
            { label: "Design", icon: Palette },
            { label: "Store", icon: Store },
          ].map((n) => (
            <span
              key={n.label}
              className={cn(
                "flex items-center gap-2 rounded-lg px-2.5 py-2",
                n.active ? "bg-accent font-semibold text-accent-foreground" : "text-muted-foreground",
              )}
            >
              <n.icon className="size-3.5" /> {n.label}
            </span>
          ))}
        </aside>
        <div className="min-w-0 p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-xs text-muted-foreground">Overview</p>
              <p className="text-base font-semibold tracking-tight">Your store is live</p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-2.5 py-1 text-[11px] font-semibold text-accent-foreground">
              <span className="size-1.5 rounded-full bg-primary" /> Online
            </span>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 sm:gap-3">
            {stats.map((s) => (
              <div key={s.label} className="rounded-xl border border-border p-2.5 sm:p-3">
                <s.icon className="size-3.5 text-primary" />
                <p className="mt-2 text-lg font-bold tracking-tight sm:text-xl">{s.value}</p>
                <p className="text-[10px] leading-tight text-muted-foreground sm:text-[11px]">{s.label}</p>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <p className="text-xs font-semibold">Recent orders</p>
            <ul className="mt-2 divide-y divide-border rounded-xl border border-border">
              {orders.map((o) => (
                <li key={o.name} className="flex items-center gap-3 px-3 py-2.5 text-[12px]">
                  <span className="grid size-7 shrink-0 place-items-center rounded-full bg-accent text-[10px] font-bold text-accent-foreground">
                    {o.name.charAt(0)}
                  </span>
                  <span className="min-w-0 flex-1 leading-tight">
                    <span className="block truncate font-medium">{o.name}</span>
                    <span className="block truncate text-muted-foreground">{o.item}</span>
                  </span>
                  <span className="font-semibold">{o.total}</span>
                  <span
                    className={cn(
                      "hidden rounded-full px-2 py-0.5 text-[10px] font-semibold min-[400px]:inline",
                      o.status === "New" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground",
                    )}
                  >
                    {o.status}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Compact previews used by the features bento grid (sample data only) */
/* ------------------------------------------------------------------ */

const catalog = [
  { name: "Chocolate truffle cake", price: "₹650", stock: "10 in stock", low: false, thumb: "from-store-cream to-chart-5/50" },
  { name: "Handmade ceramic mug", price: "₹480", stock: "2 left", low: true, thumb: "from-accent to-primary/30" },
  { name: "Festive gift hamper", price: "₹899", stock: "18 in stock", low: false, thumb: "from-chart-1/25 to-store-cream" },
];

export function ProductsMock({ className }: { className?: string }) {
  return (
    <div className={cn("w-full rounded-2xl border border-border bg-card p-3.5 shadow-soft", className)}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold">Products</span>
        <span className="inline-flex items-center gap-1 rounded-full bg-primary px-2.5 py-1 text-[10px] font-semibold text-primary-foreground">
          <Plus className="size-3" strokeWidth={3} /> Add
        </span>
      </div>
      <div className="mt-3 flex gap-1.5 text-[10px] font-medium">
        {["All", "Cakes", "Gifts", "Home"].map((c, i) => (
          <span
            key={c}
            className={cn(
              "rounded-full px-2.5 py-1",
              i === 0 ? "bg-deep text-deep-foreground" : "border border-border text-muted-foreground",
            )}
          >
            {c}
          </span>
        ))}
      </div>
      <ul className="mt-3 space-y-2">
        {catalog.map((p) => (
          <li key={p.name} className="flex items-center gap-2.5 rounded-xl border border-border/70 p-2">
            <span className={cn("size-9 shrink-0 rounded-lg bg-linear-to-br", p.thumb)} />
            <span className="min-w-0 flex-1 leading-tight">
              <span className="block truncate text-[12px] font-semibold">{p.name}</span>
              <span className="block text-[11px] text-muted-foreground">{p.price}</span>
            </span>
            <span
              className={cn(
                "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold",
                p.low ? "bg-chart-4/25 text-store-ink" : "bg-accent text-accent-foreground",
              )}
            >
              {p.stock}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

const orderSteps = ["Placed", "Packed", "Delivered"];

const availability = [
  { name: "Linen kurta", stock: "6 in stock", on: true },
  { name: "Gift hamper", stock: "Out of stock", on: false },
];

export function OrdersInventoryMock({ className }: { className?: string }) {
  return (
    <div className={cn("w-full space-y-2.5", className)}>
      <div className="rounded-2xl border border-border bg-card p-3.5 shadow-soft">
        <div className="flex items-center justify-between gap-2">
          <span className="leading-tight">
            <span className="block text-[12px] font-semibold">Order #1042</span>
            <span className="block text-[11px] text-muted-foreground">Ananya R. · Croissant box ×2</span>
          </span>
          <span className="rounded-full bg-primary px-2 py-0.5 text-[10px] font-semibold text-primary-foreground">Packed</span>
        </div>
        <ol className="mt-3.5 flex items-center">
          {orderSteps.map((s, i) => (
            <li key={s} className={cn("flex items-center", i < orderSteps.length - 1 && "flex-1")}>
              <span className="flex flex-col items-center gap-1">
                <span
                  className={cn(
                    "grid size-5 place-items-center rounded-full",
                    i < 2 ? "bg-primary text-primary-foreground" : "border-2 border-dashed border-primary/40 bg-card",
                  )}
                >
                  {i < 2 && <Check className="size-3" strokeWidth={3} />}
                </span>
                <span className={cn("text-[10px]", i < 2 ? "font-semibold" : "text-muted-foreground")}>{s}</span>
              </span>
              {i < orderSteps.length - 1 && (
                <span className={cn("mx-1.5 mb-4 h-0.5 flex-1 rounded-full", i === 0 ? "bg-primary" : "bg-border")} />
              )}
            </li>
          ))}
        </ol>
      </div>
      <div className="rounded-2xl border border-border bg-card p-3.5 shadow-soft">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Availability</p>
        <ul className="mt-2 space-y-2">
          {availability.map((a) => (
            <li key={a.name} className="flex items-center gap-2.5 text-[12px]">
              <span className="min-w-0 flex-1 leading-tight">
                <span className="block truncate font-medium">{a.name}</span>
                <span className="block text-[11px] text-muted-foreground">{a.stock}</span>
              </span>
              <span
                className={cn(
                  "flex h-[18px] w-8 shrink-0 items-center rounded-full p-0.5 transition-colors",
                  a.on ? "justify-end bg-primary" : "justify-start bg-muted ring-1 ring-border",
                )}
                aria-hidden
              >
                <span className="size-3.5 rounded-full bg-card shadow-soft" />
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

const payMethods = [
  { label: "UPI", icon: QrCode },
  { label: "Card", icon: CreditCard },
  { label: "Wallet", icon: Wallet },
];

export function CheckoutMock({ className }: { className?: string }) {
  return (
    <div className={cn("relative w-full", className)}>
      <div className="rounded-2xl border border-border bg-card p-3.5 shadow-soft">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold">Checkout</span>
          <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
            <ShoppingBag className="size-3" /> 2 items
          </span>
        </div>
        <ul className="mt-3 space-y-1.5 text-[12px]">
          <li className="flex justify-between gap-2">
            <span className="truncate text-muted-foreground">Ceramic mug ×1</span>
            <span className="font-medium">₹480</span>
          </li>
          <li className="flex justify-between gap-2">
            <span className="truncate text-muted-foreground">Truffle cake ×1</span>
            <span className="font-medium">₹650</span>
          </li>
        </ul>
        <div className="mt-3 flex items-center justify-between border-t border-dashed border-border pt-2.5">
          <span className="text-[12px] font-semibold">Total</span>
          <span className="text-sm font-bold">₹1,130</span>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-1.5">
          {payMethods.map((m, i) => (
            <span
              key={m.label}
              className={cn(
                "flex flex-col items-center gap-1 rounded-lg border py-1.5 text-[10px] font-semibold",
                i === 0 ? "border-primary bg-mint text-primary" : "border-border text-muted-foreground",
              )}
            >
              <m.icon className="size-3.5" /> {m.label}
            </span>
          ))}
        </div>
        <span className="mt-2.5 flex items-center justify-center gap-1.5 rounded-xl bg-primary-gradient py-2 text-[12px] font-semibold text-primary-foreground shadow-cta">
          <Lock className="size-3.5" /> Pay with UPI
        </span>
      </div>
      <div className="-mt-3 ml-auto mr-3 flex w-fit items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 shadow-elevated">
        <span className="grid size-5 place-items-center rounded-full bg-primary text-primary-foreground">
          <Check className="size-3" strokeWidth={3} />
        </span>
        <span className="text-[11px] font-semibold">Payment received</span>
      </div>
    </div>
  );
}

const weekSales = [
  { day: "M", h: 42 },
  { day: "T", h: 58 },
  { day: "W", h: 36 },
  { day: "T", h: 70 },
  { day: "F", h: 64 },
  { day: "S", h: 92 },
  { day: "S", h: 78 },
];

const topProducts = [
  { name: "Truffle cake", w: "w-full" },
  { name: "Gift hamper", w: "w-3/4" },
  { name: "Ceramic mug", w: "w-1/2" },
];

export function AnalyticsMock({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "grid w-full gap-2.5 rounded-2xl border border-border bg-card p-3.5 text-foreground shadow-soft sm:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)] sm:gap-4 sm:p-4",
        className,
      )}
    >
      <div>
        <div className="flex items-start justify-between gap-2">
          <span className="leading-tight">
            <span className="block text-[11px] text-muted-foreground">Sales this week</span>
            <span className="mt-0.5 block text-lg font-bold tracking-tight">₹18,420</span>
          </span>
          <span className="rounded-full border border-border px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
            Sample data
          </span>
        </div>
        <div className="mt-3 flex h-24 items-end gap-1.5 sm:h-28">
          {weekSales.map((d, i) => (
            <span key={i} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
              <span
                className={cn(
                  "w-full origin-bottom rounded-md transition-transform duration-500 group-hover:scale-y-105",
                  d.h === 92 ? "bg-primary-gradient" : "bg-primary/20",
                )}
                style={{ height: `${d.h}%` }}
              />
              <span className="text-[9px] text-muted-foreground">{d.day}</span>
            </span>
          ))}
        </div>
      </div>
      <div className="border-t border-border pt-3 sm:border-l sm:border-t-0 sm:pl-4 sm:pt-0">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Top products</p>
        <ul className="mt-2.5 space-y-2.5">
          {topProducts.map((p) => (
            <li key={p.name} className="text-[12px]">
              <span className="font-medium">{p.name}</span>
              <span className="mt-1 block h-1.5 rounded-full bg-muted">
                <span className={cn("block h-full rounded-full bg-primary", p.w)} />
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
