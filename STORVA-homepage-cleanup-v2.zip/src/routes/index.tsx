import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Check } from "lucide-react";

import { Eyebrow, Logo } from "@/components/storva/brand";
import { FeatureBento } from "@/components/storva/feature-bento";
import { PricingSection } from "@/components/storva/pricing";
import { DashboardMock } from "@/components/storva/mockups";
import { Reveal } from "@/components/storva/reveal";
import { SiteFooter } from "@/components/storva/site-footer";
import { SiteHeader } from "@/components/storva/site-header";
import { StoreShowcase } from "@/components/storva/store-showcase";
import landingCss from "../landing.css?url";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Your online store, beautifully simple · STORVA" },
      {
        name: "description",
        content:
          "STORVA helps small businesses launch an online store and manage products and orders through WhatsApp.",
      },
      { property: "og:title", content: "Your online store, beautifully simple · STORVA" },
      {
        property: "og:description",
        content:
          "STORVA helps small businesses launch an online store and manage products and orders through WhatsApp.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    // The home page has its own design system (landing.css); __root skips the app stylesheet here.
    links: [
      { rel: "stylesheet", href: landingCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1&display=swap",
      },
    ],
  }),
  component: Index,
});

const steps = [
  { title: "Set up basics", text: "Add your store name, business details and preferences." },
  { title: "Add your products", text: "Upload photos, set prices and stock, or send them on WhatsApp." },
  { title: "Choose a template", text: "Pick a layout and preview it on desktop and mobile." },
  { title: "Launch your store", text: "Connect payments and delivery, then share your link." },
];

const businesses = ["Boutiques", "Bakeries", "Handmade sellers", "Home businesses", "Gift shops"];
const promises = ["No coding needed", "Start on a free plan", "Made for mobile"];

function PrimaryLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      className="group inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary-gradient px-7 py-3.5 text-[15px] font-semibold text-primary-foreground shadow-cta transition-all hover:-translate-y-0.5 hover:brightness-105 sm:w-auto"
    >
      {children}
    </a>
  );
}

function Index() {
  return (
    <div id="top" className="relative min-h-screen overflow-x-clip bg-background text-foreground">
      <div className="absolute inset-x-0 top-0 -z-0 h-[900px] bg-hero" aria-hidden />

      <SiteHeader />

      <main className="relative">
        {/* Hero */}
        <section className="px-5 pb-16 pt-10 sm:pb-24 sm:pt-20">
          <div className="mx-auto max-w-4xl text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
            <p className="inline-flex items-center gap-2 rounded-full border border-primary/15 bg-card/80 px-3.5 py-1.5 text-xs font-medium text-foreground/80 shadow-soft backdrop-blur">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary/50" />
                <span className="relative inline-flex size-2 rounded-full bg-primary" />
              </span>
              A small business, with big possibilities
            </p>
            <h1 className="mt-7 text-[2.4rem] font-bold leading-[1.04] min-[400px]:text-[2.65rem] sm:text-6xl lg:text-[5.25rem]">
              Your online store.
              <br />
              <span className="font-serif font-normal italic tracking-normal text-primary">A whole new chapter.</span>
            </h1>
            <p className="mx-auto mt-6 max-w-xl text-[17px] leading-relaxed text-muted-foreground sm:text-lg">
              Create your own online store with <strong className="font-semibold text-foreground">STORVA</strong>.
              Showcase your products and grow your business with ease.
            </p>
            <div className="mx-auto mt-9 flex max-w-sm flex-col items-center justify-center gap-3 sm:max-w-none sm:flex-row">
              <PrimaryLink href="#start">
                Start for free <ArrowUpRight className="size-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </PrimaryLink>
              <a
                href="#services"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-border bg-card/80 px-7 py-3.5 text-[15px] font-semibold shadow-soft backdrop-blur transition-colors hover:bg-card sm:w-auto"
              >
                See what you get <ArrowRight className="size-4" />
              </a>
            </div>
            <ul className="mt-7 flex flex-wrap justify-center gap-x-6 gap-y-2 text-[13px] text-muted-foreground">
              {promises.map((t) => (
                <li key={t} className="inline-flex items-center gap-1.5">
                  <span className="grid size-4 place-items-center rounded-full bg-accent">
                    <Check className="size-2.5 text-primary" strokeWidth={3} />
                  </span>
                  {t}
                </li>
              ))}
            </ul>
          </div>

          <div className="relative mx-auto mt-12 max-w-5xl animate-in fade-in slide-in-from-bottom-8 duration-1000 sm:mt-16">
            <div className="absolute -inset-x-10 -bottom-10 top-10 -z-10 rounded-[3rem] bg-primary/15 blur-3xl" aria-hidden />
            <StoreShowcase />
          </div>
        </section>

        {/* Businesses */}
        <section className="border-y border-border bg-mint/70 py-5">
          <div className="mx-auto flex max-w-6xl flex-col items-center gap-3 px-5 md:flex-row md:gap-8">
            <span className="shrink-0 text-[11px] font-semibold uppercase tracking-[0.2em] text-primary">
              Built for your business
            </span>
            <div className="w-full overflow-hidden mask-fade-x">
              <div className="flex w-max animate-marquee gap-10 pr-10">
                {[...businesses, ...businesses, ...businesses, ...businesses].map((b, i) => (
                  <span
                    key={`${b}-${i}`}
                    className="flex items-center gap-10 whitespace-nowrap font-display text-[15px] font-semibold text-foreground/70"
                    aria-hidden={i >= businesses.length}
                  >
                    {b}
                    <span className="size-1 rounded-full bg-primary/40" />
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        <FeatureBento />

        {/* How it works */}
        <section id="how-it-works" className="scroll-mt-16 px-3 sm:px-5">
          <div className="relative mx-auto max-w-7xl overflow-hidden rounded-[2rem] bg-deep-gradient px-5 py-16 text-deep-foreground sm:rounded-[2.5rem] sm:px-10 sm:py-24 lg:px-16">
            <div className="absolute inset-0 bg-grid opacity-40 mask-fade-b" aria-hidden />
            <div className="relative grid items-center gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-16">
              <div>
                <Reveal>
                  <Eyebrow tone="inverse">From idea to open for business</Eyebrow>
                  <h2 className="mt-4 text-[2rem] font-bold leading-[1.08] sm:text-5xl">
                    Your store in{" "}
                    <span className="font-serif font-normal italic tracking-normal text-primary-glow">four steps.</span>
                  </h2>
                </Reveal>
                <ol className="relative mt-10 space-y-1">
                  <span className="absolute bottom-6 left-[19px] top-6 w-px bg-deep-foreground/15" aria-hidden />
                  {steps.map((s, i) => (
                    <Reveal key={s.title} delay={i * 90}>
                      <li className="relative flex gap-5 rounded-2xl p-2 transition-colors hover:bg-deep-foreground/5">
                        <span className="relative grid size-10 shrink-0 place-items-center rounded-full border border-deep-foreground/20 bg-deep font-display text-sm font-bold text-primary-glow">
                          0{i + 1}
                        </span>
                        <div className="pb-4 pt-1.5">
                          <h3 className="text-lg font-semibold">{s.title}</h3>
                          <p className="mt-1 text-[15px] leading-relaxed text-deep-muted">{s.text}</p>
                        </div>
                      </li>
                    </Reveal>
                  ))}
                </ol>
              </div>
              <Reveal delay={150}>
                <div className="relative">
                  <div className="absolute -inset-6 -z-0 rounded-[2.5rem] bg-primary-glow/20 blur-3xl" aria-hidden />
                  <DashboardMock className="relative" />
                </div>
              </Reveal>
            </div>
          </div>
        </section>

        <PricingSection />

        {/* Start */}
        <section id="start" className="scroll-mt-16 px-5 py-20 sm:py-28">
          <Reveal className="relative mx-auto max-w-4xl overflow-hidden rounded-[2rem] border border-border bg-mint px-6 py-14 text-center shadow-soft sm:rounded-[2.5rem] sm:px-12 sm:py-20">
            <div className="absolute inset-0 bg-grid mask-fade-b" aria-hidden />
            <div className="absolute -top-24 left-1/2 h-48 w-2/3 -translate-x-1/2 rounded-full bg-primary/20 blur-3xl" aria-hidden />
            <div className="relative">
              <Eyebrow>Your next chapter starts here</Eyebrow>
              <h2 className="mt-4 text-[2.1rem] font-bold leading-[1.05] sm:text-6xl">
                Ready to open{" "}
                <span className="font-serif font-normal italic tracking-normal text-primary">your store?</span>
              </h2>
              <p className="mx-auto mt-5 max-w-md text-[17px] text-muted-foreground">
                Start on the free plan. Upgrade only when you grow.
              </p>
              <div className="mx-auto mt-9 flex max-w-sm justify-center sm:max-w-none">
                <PrimaryLink href="/login">
                  Create my store <ArrowUpRight className="size-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </PrimaryLink>
              </div>
              <ul className="mt-7 flex flex-wrap justify-center gap-x-6 gap-y-2 text-[13px] text-muted-foreground">
                {promises.map((t) => (
                  <li key={t} className="inline-flex items-center gap-1.5">
                    <Check className="size-3.5 text-primary" /> {t}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
